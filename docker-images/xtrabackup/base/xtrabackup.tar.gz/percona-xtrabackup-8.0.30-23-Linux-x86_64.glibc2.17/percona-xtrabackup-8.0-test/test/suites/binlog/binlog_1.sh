. inc/common.sh
. inc/binlog_common.sh
vlog "------- TEST 1 -------"
INDEX_FILE=""
FILES=""
backup_restore --skip-log-bin
